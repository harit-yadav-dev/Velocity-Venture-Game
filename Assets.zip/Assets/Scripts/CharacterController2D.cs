using UnityEngine;
using UnityEngine.Events;
using UnityEngine.Serialization;
public class PlayerController2D : MonoBehaviour
{
    [FormerlySerializedAs("m_JumpForce")]
    [SerializeField] private float jumpImpulse = 400f;
    [FormerlySerializedAs("m_CrouchSpeed")]
    [Range(0,1)]
    [SerializeField] private float crouchFactor = 0.36f;
    [FormerlySerializedAs("m_MovementSmoothing")]
    [Range(0,0.3f)]
    [SerializeField] private float smoothingTime = 0.05f;
    [FormerlySerializedAs("m_AirControl")]
    [SerializeField] private bool canAirControl = true;
    [FormerlySerializedAs("m_WhatIsGround")]
    [SerializeField] private LayerMask groundLayers;
    [FormerlySerializedAs("m_GroundCheck")]
    [SerializeField] private Transform groundCheckPoint;
    [FormerlySerializedAs("m_CeilingCheck")]
    [SerializeField] private Transform ceilingCheckPoint;
    [FormerlySerializedAs("m_CrouchDisableCollider")]
    [SerializeField] private Collider2D crouchDisable;
    const float groundRadius = 0.2f;
    bool isGrounded;
    const float ceilingRadius = 0.2f;
    Rigidbody2D rb;
    bool facingRight = true;
    Vector3 velocityRef = Vector3.zero;
    [Header("Events")]
    public UnityEvent OnLandEvent;
    [System.Serializable]
    public class BoolEvent : UnityEvent<bool>{}
    public BoolEvent OnCrouchEvent;
    bool wasCrouching;
    public float JumpForce
    {
        get => jumpImpulse;
        set => jumpImpulse = value;
    }
    void Awake()
    {
        rb = GetComponent<Rigidbody2D>();
        if (OnLandEvent == null)
            OnLandEvent = new UnityEvent();
        if (OnCrouchEvent == null)
            OnCrouchEvent = new BoolEvent();
    }
    void FixedUpdate()
    {
        bool wasGroundedPrev = isGrounded;
        isGrounded = false;
        Collider2D[] hits = Physics2D.OverlapCircleAll(groundCheckPoint.position, groundRadius, groundLayers);
        for (int i = 0; i < hits.Length; i++)
        {
            if (hits[i].gameObject != gameObject)
            {
                isGrounded = true;
                if (!wasGroundedPrev)
                    OnLandEvent.Invoke();
            }
        }
    }
    public void Move(float moveVal, bool crouchVal, bool jumpVal)
    {
        if (!crouchVal)
        {
            if (Physics2D.OverlapCircle(ceilingCheckPoint.position, ceilingRadius, groundLayers))
                crouchVal = true;
        }
        if (isGrounded || canAirControl)
        {
            if (crouchVal)
            {
                if (!wasCrouching)
                {
                    wasCrouching = true;
                    OnCrouchEvent.Invoke(true);
                }
                moveVal *= crouchFactor;
                if (crouchDisable != null)
                    crouchDisable.enabled = false;
            }
            else
            {
                if (crouchDisable != null)
                    crouchDisable.enabled = true;
                if (wasCrouching)
                {
                    wasCrouching = false;
                    OnCrouchEvent.Invoke(false);
                }
            }
            Vector3 targetVel = new Vector2(moveVal * 10f, rb.linearVelocity.y);
            rb.linearVelocity = Vector3.SmoothDamp(rb.linearVelocity, targetVel, ref velocityRef, smoothingTime);
            if (moveVal > 0 && !facingRight)
                Flip();
            else if (moveVal < 0 && facingRight)
                Flip();
        }
        if (isGrounded && jumpVal)
        {
            isGrounded = false;
            rb.AddForce(new Vector2(0f, jumpImpulse));
        }
    }
    void Flip()
    {
        facingRight = !facingRight;
        Vector3 sc = transform.localScale;
        sc.x *= -1;
        transform.localScale = sc;
    }
}
