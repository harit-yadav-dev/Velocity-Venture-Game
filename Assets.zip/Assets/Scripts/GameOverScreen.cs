using UnityEngine;
using UnityEngine.UI;

public class GameOverDisplay : MonoBehaviour
{
    [Header("Run Results UI")]
    public Text labelTime;
    public Text labelCoins;

    void Start()
    {
        float storedTime  = PlayerPrefs.GetFloat("TimeSurvived", 0f);
        int   storedCoins = PlayerPrefs.GetInt  ("CoinsCollected", 0);
        labelTime.text  = $"Time Survived: {Mathf.RoundToInt(storedTime)} s";
        labelCoins.text = $"Coins Collected: {storedCoins}";
    }
}
