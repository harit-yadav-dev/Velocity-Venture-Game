using UnityEngine;
using UnityEngine.SceneManagement;
public class GamePauseHandler : MonoBehaviour
{
    public GameObject pauseUI;
    private bool paused;
    void Start()
    {
        if (pauseUI != null)
        {
            pauseUI.SetActive(false);
        }
    }
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Escape))
        {
            if (paused)
            {
                Unpause();
            }
            else
            {
                TriggerPause();
            }
        }
    }
    public void Unpause()
    {
        pauseUI.SetActive(false);
        Time.timeScale = 1;
        paused = false;
    }
    public void TriggerPause()
    {
        pauseUI.SetActive(true);
        Time.timeScale = 0;
        paused = true;
    }
    public void GoToMenu()
    {
        Time.timeScale = 1;
        SceneManager.LoadScene("StartScene");
    }
    public void ExitApp()
    {
        Application.Quit();
        Debug.Log("Exited");
    }
}
