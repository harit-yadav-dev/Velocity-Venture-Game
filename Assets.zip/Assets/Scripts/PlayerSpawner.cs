using UnityEngine;
public class PlayerSpawner : MonoBehaviour
{
    public GameObject[] skinPrefabs; 
    public Vector3 spawnPosition = Vector3.zero; 
    void Start()
    {
        int skinIndex = PlayerPrefs.GetInt("SelectedSkin", 0);
        GameObject playerPrefab = skinPrefabs[skinIndex];
        Instantiate(playerPrefab, spawnPosition, Quaternion.identity);
    }
}
