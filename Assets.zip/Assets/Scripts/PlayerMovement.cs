using UnityEngine;
using System.Collections;
using UnityEngine.Serialization;
public class PlayerMovement : MonoBehaviour
{
    [Header("Movement & Jumping")]
    public PlayerController2D moveController;   
    public float moveSpeed = 40f;
    public float jumpForce = 15f;               
    public int maxJumps = 2;                
    [Header("Death & Effects")]
    public float killY = -10f;
    public GameObject explosionPrefab;
    public AudioClip deathSFX;
    public float deathSFXVolume = 1f;
    [Header("Audio & Anim")]
    public AudioClip jumpSFX;
    public float jumpSFXVolume = 0.3f;
    public Animator charAnimator;
    [Header("Other")]
    public CoinController coinController;
    private AudioSource audioSource;
    private Rigidbody2D rb;
    private Vector3 spawnPoint;
    private int jumpCount = 0;
    private float horizontalInput;
    private bool dead = false;

    void Awake()
    {
        rb = GetComponent<Rigidbody2D>();
        audioSource = GetComponent<AudioSource>();
        if (audioSource != null) audioSource.playOnAwake = false;
    }

    void Start()
    {
        charAnimator = GetComponent<Animator>();
        spawnPoint = transform.position;
        if (moveController.OnLandEvent != null)
            moveController.OnLandEvent.AddListener(OnLandingEvent);
    }

    void Update()
    {
        if (dead) return;
        horizontalInput = Input.GetAxisRaw("Horizontal") * moveSpeed;
        charAnimator.SetFloat("Speed", Mathf.Abs(horizontalInput));
        if (Input.GetButtonDown("Jump") && jumpCount < maxJumps)
        {
            PerformJump();
        }
        if (Input.GetKeyDown(KeyCode.Space) && jumpCount > 0)
            charAnimator.SetTrigger("BackFlip");
        if (transform.position.y < killY)
            StartCoroutine(FallAndDie());
    }

    void FixedUpdate()
    {
        if (dead) return;
        moveController.Move(horizontalInput * Time.fixedDeltaTime, false, false);
    }

    private void PerformJump()
    {
        jumpCount++;
        rb.linearVelocity = new Vector2(rb.linearVelocity.x, 0f);
        rb.AddForce(Vector2.up * jumpForce, ForceMode2D.Impulse);

        charAnimator.SetBool("isJumping", true);
        if (jumpSFX != null && audioSource != null)
            audioSource.PlayOneShot(jumpSFX, jumpSFXVolume);
    }

    public void OnLandingEvent()
    {
        jumpCount = 0;
        charAnimator.SetBool("isJumping", false);
    }

    void OnTriggerEnter2D(Collider2D other)
    {
        if (dead) return;
        if (other.CompareTag("Coin"))
        {
            var cc = Object.FindFirstObjectByType<CoinController>();
            if (cc != null) cc.CollectCoin(other.gameObject);
        }
        else if (other.CompareTag("Enemy"))
        {
            HandleEnemyCollision(other.gameObject);
        }
    }
    void OnCollisionEnter2D(Collision2D col)
    {
        if (dead) return;
        if (col.gameObject.CompareTag("Enemy"))
            HandleEnemyCollision(col.gameObject);
    }
    void HandleEnemyCollision(GameObject enemy)
    {
        if (explosionPrefab != null)
            Instantiate(explosionPrefab, transform.position, Quaternion.identity);

        Destroy(enemy);
        StartCoroutine(FallAndDie());
    }
    IEnumerator FallAndDie()
    {
        dead = true;
        charAnimator.SetTrigger("FallDown");

        if (deathSFX != null && audioSource != null)
        {
            audioSource.clip = deathSFX;
            audioSource.loop = true;
            audioSource.Play();
        }
        yield return new WaitForSeconds(2f);
        if (audioSource != null)
        {
            audioSource.Stop();
            audioSource.loop = false;
        }
        var lives = Object.FindFirstObjectByType<LivesManager>();
        if (lives != null) lives.DecreaseLife();
        else
        {
            var gc = Object.FindFirstObjectByType<GameController>();
            if (gc != null) gc.GameOver();
        }
    }
    public void Respawn()
    {
        transform.position = spawnPoint;
        dead = false;
        charAnimator.SetTrigger("Respawn");
    }
}
