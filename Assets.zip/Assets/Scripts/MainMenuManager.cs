using UnityEngine;
using UnityEngine.SceneManagement;

public class MenuManager : MonoBehaviour
{
    [Tooltip("Exact name of your gameplay scene")]
    public string GameSceneName = "Level_1";
    public void StartGame()
    {
        SceneManager.LoadScene(GameSceneName);
    }
    public void QuitGame()
    {
    #if UNITY_EDITOR
        UnityEditor.EditorApplication.isPlaying = false;
    #else
        Application.Quit();
    #endif
    }
}
