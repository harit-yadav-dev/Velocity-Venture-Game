using UnityEngine;
using UnityEngine.Serialization;
public class EnemyCar : MonoBehaviour
{
    [FormerlySerializedAs("moveSpeed")]
    public float driveSpeed = 2f;
    int heading = 1;
    float boundary;
    public static System.Action OnCarExit;
    void Start()
    {
        heading = transform.position.x < Camera.main.transform.position.x ? 1 : -1;
        if (heading == 1)
            transform.rotation = Quaternion.Euler(0f, 180f, 0f);
        else
            transform.rotation = Quaternion.Euler(0f, 0f, 0f);
        boundary = Camera.main.orthographicSize * Camera.main.aspect + 5f;
    }
    void Update()
    {
        transform.Translate(Vector2.right * heading * driveSpeed * Time.deltaTime);
        if (Mathf.Abs(transform.position.x - Camera.main.transform.position.x) > boundary + 3f)
        {
            Destroy(gameObject);
            OnCarExit?.Invoke();
        }
    }
}
