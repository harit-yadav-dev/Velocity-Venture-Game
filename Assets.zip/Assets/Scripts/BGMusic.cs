using UnityEngine;
using UnityEngine.Serialization;

public class BackgroundMusic : MonoBehaviour
{
    [FormerlySerializedAs("bgmSource")]
    public AudioSource audioComp;
    [FormerlySerializedAs("bgmClip")]
    public AudioClip musicClip;

    void Start()
    {
        if (audioComp == null)
            audioComp = gameObject.AddComponent<AudioSource>();
        audioComp.clip = musicClip;
        audioComp.loop = true;
        audioComp.playOnAwake = true;
        audioComp.volume = 0.5f;
        audioComp.Play();
    }
}
