using UnityEngine;
using UnityEngine.Serialization;
public class CoinPickup : MonoBehaviour
{
    [FormerlySerializedAs("collected")]
    public bool wasCollected = false;
    Vector3 initialPos;
    void Awake()
    {
        initialPos = transform.position;
    }
    void OnTriggerEnter2D(Collider2D other)
    {
        if (!wasCollected && other.CompareTag("Player"))
        {
            wasCollected = true;
            Collider2D col = GetComponent<Collider2D>();
            if (col != null)
                col.enabled = false;
            CoinController manager = Object.FindFirstObjectByType<CoinController>();
            if (manager != null)
                manager.CollectCoin(gameObject);
        }
    }
    public void ResetPickup()
    {
        wasCollected = false;
        transform.position = initialPos;
        Collider2D col = GetComponent<Collider2D>();
        if (col != null)
            col.enabled = true;
    }
}
