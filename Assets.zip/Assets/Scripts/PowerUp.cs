using UnityEngine;

public class PowerUp : MonoBehaviour
{
    public string powerType;

    void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("Player"))
        {
            PowerUpManager manager = other.GetComponent<PowerUpManager>();
            if (manager != null)
            {
                manager.ActivatePower(powerType);
                gameObject.SetActive(false);
            }
        }
    }
}
