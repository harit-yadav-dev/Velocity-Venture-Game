using UnityEngine;
public class HeartPickup : MonoBehaviour
{
    void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("Player"))
        {
            LivesManager lm = FindFirstObjectByType<LivesManager>();
            if (lm != null)
            {
                lm.AddLife();
                Destroy(gameObject);
            }
        }
    }
}
