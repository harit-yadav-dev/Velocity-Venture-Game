using System.Collections;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.Serialization;
public class CoinController : MonoBehaviour
{
    [FormerlySerializedAs("coinCount")]
    public int totalCoins = 0;
    [FormerlySerializedAs("coinText")]
    public Text coinDisplay;
    [FormerlySerializedAs("coinSound")]
    public AudioClip coinAudio;
    AudioSource coinSource;
    void Start()
    {
        coinSource = GetComponent<AudioSource>();
        RefreshUI();
    }
    public void CollectCoin(GameObject coinObj)
    {
        totalCoins++;
        RefreshUI();
        if (coinAudio != null && coinSource != null)
            coinSource.PlayOneShot(coinAudio);
        StartCoroutine(RespawnRoutine(coinObj));
    }
    IEnumerator RespawnRoutine(GameObject coinObj)
    {
        yield return StartCoroutine(MoveCoinToUI(coinObj));
        coinObj.SetActive(false);
        yield return new WaitForSeconds(5f);
        coinObj.SetActive(true);
        CoinPickup pickup = coinObj.GetComponent<CoinPickup>();
        if (pickup != null)
            pickup.ResetPickup();
    }
    IEnumerator MoveCoinToUI(GameObject coinObj)
    {
        RectTransform rectUI = coinDisplay.GetComponent<RectTransform>();
        Vector3 endPos = Camera.main.ScreenToWorldPoint(rectUI.position);
        endPos.z = coinObj.transform.position.z;
        Vector3 startPos = coinObj.transform.position;
        float timeDur = 1f;
        float curr = 0f;
        while (curr < timeDur)
        {
            curr += Time.deltaTime;
            float t = curr / timeDur;
            float arc = 2f * t * (1 - t);
            Vector3 nPos = Vector3.Lerp(startPos, endPos, t);
            nPos.y += arc;
            coinObj.transform.position = nPos;
            yield return null;
        }
        coinObj.transform.position = endPos;
    }
    void RefreshUI()
    {
        if (coinDisplay != null)
            coinDisplay.text = "Coins: " + totalCoins;
    }
}
