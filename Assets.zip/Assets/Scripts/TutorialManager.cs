using UnityEngine;
using UnityEngine.SceneManagement;
public class TutorialManager : MonoBehaviour
{
    public GameObject tutorialPanel;
    void Start()
    {
        if (tutorialPanel != null)
            tutorialPanel.SetActive(false);
    }
    public void OpenTutorial()
    {
        if (tutorialPanel != null)
            tutorialPanel.SetActive(true);
    }
    public void CloseTutorial()
    {
        SceneManager.LoadScene("StartScene"); 
    }
}
