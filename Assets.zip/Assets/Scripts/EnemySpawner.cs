using UnityEngine;
using System.Collections;
using UnityEngine.Serialization;
public class EnemySpawner : MonoBehaviour
{
    [FormerlySerializedAs("enemyCarPrefabs")]
    public GameObject[] carVariants;
    [FormerlySerializedAs("fixedSpeed")]
    public float defaultSpeed = 2f;
    [FormerlySerializedAs("minSpawnInterval")]
    public float minDelay = 1.5f;
    [FormerlySerializedAs("maxSpawnInterval")]
    public float maxDelay = 3f;
    [FormerlySerializedAs("spawnYOffsetMin")]
    public float yMin = -4f;
    [FormerlySerializedAs("spawnYOffsetMax")]
    public float yMax = 0f;
    [FormerlySerializedAs("spawnHorizontalOffset")]
    public float extraOffset = 2f;
    float screenW;
    void Awake()
    {
        screenW = Camera.main.orthographicSize * Camera.main.aspect;
    }
    void Start()
    {
        StartCoroutine(SpawnCycle());
    }
    IEnumerator SpawnCycle()
    {
        while (true)
        {
            SpawnCar();
            float waitT = Random.Range(minDelay, maxDelay);
            yield return new WaitForSeconds(waitT);
        }
    }
    void SpawnCar()
    {
        int idx = Random.Range(0, carVariants.Length);
        GameObject carObj = carVariants[idx];
        if (carObj == null) return;
        Camera cam = Camera.main;
        Vector3 cPos = cam.transform.position;
        float spawnY = cPos.y + Random.Range(yMin, yMax);
        bool leftSide = Random.Range(0, 2) == 0;
        float spawnX = leftSide ? cPos.x - screenW - extraOffset : cPos.x + screenW + extraOffset;
        Vector3 spawnPos = new Vector3(spawnX, spawnY, 0f);
        GameObject instance = Instantiate(carObj, spawnPos, Quaternion.identity);
        EnemyCar e = instance.GetComponent<EnemyCar>();
        if (e != null)
            e.driveSpeed = defaultSpeed;
        Debug.Log("Spawned: " + carObj.name + " at " + spawnPos + " from " + (leftSide ? "Left" : "Right"));
    }
}
