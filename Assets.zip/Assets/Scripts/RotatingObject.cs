using UnityEngine;

public class RotateObject : MonoBehaviour
{
    public float angle = 45f;
    public float speed = 2f;

    void Update()
    {
        float z = Mathf.Sin(Time.time * speed) * angle;
        transform.rotation = Quaternion.Euler(0f, 0f, z);
    }
}
