using UnityEngine;
using UnityEngine.Serialization;

public class ItemCollect : MonoBehaviour
{
    AudioSource itemAudio;

    void Start()
    {
        itemAudio = GetComponent<AudioSource>();
    }

    void OnTriggerEnter2D(Collider2D col)
    {
        if (col.gameObject.CompareTag("Player"))
        {
            itemAudio.Play();
        }
    }
}
