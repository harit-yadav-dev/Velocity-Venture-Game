using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using System.Collections;
using TMPro;
public class SplashController : MonoBehaviour
{
    public Text continueText;  
    public float blinkRate = 0.5f;
    public string nextScene = "StartScene";
    private Coroutine _blinkRoutine;
    void Start()
    {
        _blinkRoutine = StartCoroutine(Blink());
    }
    IEnumerator Blink()
    {
        while (true)
        {
            continueText.gameObject.SetActive(!continueText.gameObject.activeSelf);
            yield return new WaitForSeconds(blinkRate);
        }
    }
    void Update()
    {
        if (Input.GetMouseButtonDown(0) || Input.anyKeyDown)
        {
            if (_blinkRoutine != null) StopCoroutine(_blinkRoutine);
            continueText.gameObject.SetActive(true);
            SceneManager.LoadScene(nextScene);
        }
    }
}
