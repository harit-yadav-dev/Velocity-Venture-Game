using UnityEngine;
public class FloatingAnimation : MonoBehaviour
{
    public float floatStrength = 0.5f;
    public float speed = 2f;
    private Vector3 startPos;
    void Start()
    {
        startPos = transform.position;
    }
    void Update()
    {
        transform.position = startPos + new Vector3(0f, Mathf.Sin(Time.time * speed) * floatStrength, 0f);
    }
}
