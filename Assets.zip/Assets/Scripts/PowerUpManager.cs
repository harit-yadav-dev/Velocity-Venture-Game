using UnityEngine;

public class PowerUpManager : MonoBehaviour
{
    public void ActivatePower(string powerType)
    {
        if (powerType == "Life")
        {
            LivesManager lives = FindAnyObjectByType<LivesManager>();
            if (lives != null)
                lives.AddLife();
        }
    }
}
