using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.Serialization;
public class GameController : MonoBehaviour
{
    float timeSurvived = 0f;

    void Update()
    {
        timeSurvived += Time.deltaTime;
    }
    public void GameOver()
    {
        CoinController coinCtrl = Object.FindFirstObjectByType<CoinController>();
        if (coinCtrl != null)
            PlayerPrefs.SetInt("CoinsCollected", coinCtrl.totalCoins);
        PlayerPrefs.SetFloat("TimeSurvived", timeSurvived);
        PlayerPrefs.Save();
        SceneManager.LoadScene("GameOver");
    }
}
