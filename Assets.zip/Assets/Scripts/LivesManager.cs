using UnityEngine;
using TMPro;
public class LivesManager : MonoBehaviour
{
    public int totalLives = 1;
    public TextMeshProUGUI livesText;
    void Start()
    {
        UpdateLivesUI();
    }
    public void DecreaseLife()
    {
        totalLives--;
        UpdateLivesUI();

        if (totalLives <= 0)
        {
            GameController gm = FindFirstObjectByType<GameController>();
            if (gm != null) gm.GameOver();
        }
        else
        {
            PlayerMovement player = FindFirstObjectByType<PlayerMovement>();
            if (player != null) player.Respawn();
        }
    }
    public void AddLife()
    {
        totalLives++;
        UpdateLivesUI();
    }
    void UpdateLivesUI()
    {
        if (livesText != null)
            livesText.text = "Lives: " + totalLives;
    }
}
